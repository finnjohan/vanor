// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import Lomiri.Components.Pickers 1.3
import "Logic.js" as Logic

Page {
    id: page
    property int habitId: -1
    property var habit: habitId >= 0 ? root.habitById(habitId) : null
    property string selectedColor: habit ? habit.color : root.habitColors[root.habits.count % root.habitColors.length]
    property int reminderDays: habit ? habit.reminderDays : 127

    function save() {
        var name = nameField.text.trim()
        if (name.length === 0) {
            nameField.forceActiveFocus()
            return
        }
        var t = timePicker.date
        root.saveHabit(page.habitId, {
            name: name,
            color: page.selectedColor,
            perWeek: goal.selectedIndex + 1,
            reminderOn: root.remindersEnabled ? reminderSwitch.checked : (page.habit ? page.habit.reminderOn : false),
            reminderTime: Logic.pad(t.getHours()) + ":" + Logic.pad(t.getMinutes()),
            reminderDays: page.reminderDays
        })
        stack.pop()
    }

    header: PageHeader {
        id: header
        title: page.habit ? root.tr("Edit habit") : root.tr("New habit")
        trailingActionBar.actions: [
            Action {
                iconName: "ok"
                text: root.tr("Save")
                enabled: nameField.text.trim().length > 0
                onTriggered: page.save()
            }
        ]
    }

    Flickable {
        id: flick
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: form.height + units.gu(4)
        clip: true

        Column {
            id: form
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(1.5)

            Label { text: root.tr("Name"); font.weight: Font.Medium }
            TextField {
                id: nameField
                width: parent.width
                placeholderText: root.tr("e.g. Exercise, Read 20 min, Meditate")
                text: page.habit ? page.habit.name : ""
                onAccepted: page.save()
                Component.onCompleted: if (!page.habit) forceActiveFocus()
            }

            Item { width: 1; height: units.gu(0.5) }
            Label { text: root.tr("Goal"); font.weight: Font.Medium }
            OptionSelector {
                id: goal
                width: parent.width
                expanded: false
                model: [1, 2, 3, 4, 5, 6, 7].map(function (n) { return Logic.goalText(n, root.lang) })
                selectedIndex: page.habit ? page.habit.perWeek - 1 : 6
            }

            Item { width: 1; height: units.gu(0.5) }
            Label { text: root.tr("Color"); font.weight: Font.Medium }
            Flow {
                width: parent.width
                spacing: units.gu(1.5)
                Repeater {
                    model: root.habitColors
                    AbstractButton {
                        width: units.gu(5); height: units.gu(5)
                        onClicked: page.selectedColor = modelData
                        Rectangle {
                            anchors.fill: parent
                            radius: width / 2
                            color: modelData
                            border.width: page.selectedColor === modelData ? units.dp(3) : 0
                            border.color: theme.palette.normal.baseText
                        }
                        Label {
                            anchors.centerIn: parent
                            visible: page.selectedColor === modelData
                            text: "✓"; color: "white"; font.bold: true
                        }
                    }
                }
            }

            // ---- Påminnelse (dold när remindersEnabled är false) ----
            Item { width: 1; height: units.gu(0.5); visible: root.remindersEnabled }
            Item {
                width: parent.width
                height: units.gu(4)
                visible: root.remindersEnabled
                Label {
                    anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                    text: root.tr("Remind me")
                    font.weight: Font.Medium
                }
                Switch {
                    id: reminderSwitch
                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                    checked: page.habit ? page.habit.reminderOn : false
                }
            }

            Column {
                width: parent.width
                spacing: units.gu(1.5)
                visible: root.remindersEnabled && reminderSwitch.checked

                DatePicker {
                    id: timePicker
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: units.gu(30)
                    height: units.gu(16)
                    mode: "Hours|Minutes"
                    date: {
                        var t = (page.habit ? page.habit.reminderTime : "20:00").split(":")
                        var d = new Date()
                        d.setHours(parseInt(t[0], 10), parseInt(t[1], 10), 0, 0)
                        return d
                    }
                }

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: units.gu(0.6)
                    Repeater {
                        model: 7
                        AbstractButton {
                            id: dayChip
                            width: units.gu(5); height: units.gu(5)
                            property bool on: (page.reminderDays & (1 << index)) !== 0
                            onClicked: page.reminderDays = page.reminderDays ^ (1 << index)
                            Rectangle {
                                anchors.fill: parent
                                radius: width / 2
                                color: dayChip.on ? page.selectedColor : "transparent"
                                border.width: dayChip.on ? 0 : units.dp(1)
                                border.color: theme.palette.normal.base
                            }
                            Label {
                                anchors.centerIn: parent
                                text: Logic.dayName(index, root.lang).substring(0, 2)
                                textSize: Label.Small
                                color: dayChip.on ? "white" : theme.palette.normal.baseText
                            }
                        }
                    }
                }

                Label {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    textSize: Label.Small
                    color: theme.palette.normal.backgroundSecondaryText
                    text: root.tr("The reminder rings like an alarm and is also listed in the Clock app.")
                }
            }

            // Förhandsvisning
            Item { width: 1; height: units.gu(0.5) }
            Rectangle {
                width: parent.width
                height: units.gu(6)
                radius: units.gu(1)
                color: Qt.rgba(0.5, 0.5, 0.5, 0.1)
                Row {
                    anchors { left: parent.left; leftMargin: units.gu(2); verticalCenter: parent.verticalCenter }
                    spacing: units.gu(1.5)
                    ScoreRing { width: units.gu(3.5); height: width; value: 0.7; ringColor: page.selectedColor }
                    Label {
                        anchors.verticalCenter: parent.verticalCenter
                        text: nameField.text.trim().length > 0 ? nameField.text : root.tr("Preview")
                        color: page.selectedColor
                        font.weight: Font.Medium
                    }
                }
            }
        }
    }
}
