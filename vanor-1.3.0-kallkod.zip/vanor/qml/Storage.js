.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
.import QtQuick.LocalStorage 2.0 as Sql

var _db = null

function _tryExec(tx, sql) {
    try { tx.executeSql(sql) } catch (e) { /* kolumnen finns redan */ }
}

function db() {
    if (_db) return _db
    _db = Sql.LocalStorage.openDatabaseSync("vanor", "1.0", "Vanor", 1000000)
    _db.transaction(function (tx) {
        tx.executeSql("CREATE TABLE IF NOT EXISTS habits (" +
                      "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, " +
                      "color TEXT NOT NULL, per_week INTEGER NOT NULL, " +
                      "created TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0)")
        tx.executeSql("CREATE TABLE IF NOT EXISTS checks (" +
                      "habit_id INTEGER NOT NULL, day TEXT NOT NULL, " +
                      "PRIMARY KEY (habit_id, day))")
        tx.executeSql("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
    })
    // Version 1.1: påminnelser (läggs till på befintliga databaser)
    _db.transaction(function (tx) {
        _tryExec(tx, "ALTER TABLE habits ADD COLUMN reminder_on INTEGER NOT NULL DEFAULT 0")
        _tryExec(tx, "ALTER TABLE habits ADD COLUMN reminder_time TEXT NOT NULL DEFAULT '20:00'")
        _tryExec(tx, "ALTER TABLE habits ADD COLUMN reminder_days INTEGER NOT NULL DEFAULT 127")
    })
    return _db
}

function setting(key, fallback) {
    var v = fallback
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT value FROM settings WHERE key = ?", [key])
        if (rs.rows.length > 0) v = rs.rows.item(0).value
    })
    return v
}

function setSetting(key, value) {
    db().transaction(function (tx) {
        tx.executeSql("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, String(value)])
    })
}

function habits() {
    var out = []
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT * FROM habits ORDER BY position, id")
        for (var i = 0; i < rs.rows.length; i++) {
            var r = rs.rows.item(i)
            out.push({ id: r.id, name: r.name, color: r.color,
                       perWeek: r.per_week, created: r.created,
                       reminderOn: r.reminder_on === 1, reminderTime: r.reminder_time,
                       reminderDays: r.reminder_days })
        }
    })
    return out
}

function checks(habitId) {
    var out = {}
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT day FROM checks WHERE habit_id = ?", [habitId])
        for (var i = 0; i < rs.rows.length; i++) out[rs.rows.item(i).day] = true
    })
    return out
}

// h: { name, color, perWeek, reminderOn, reminderTime, reminderDays }
function addHabit(h, created) {
    db().transaction(function (tx) {
        var rs = tx.executeSql("SELECT COALESCE(MAX(position), 0) + 1 AS p FROM habits")
        tx.executeSql("INSERT INTO habits (name, color, per_week, created, position, " +
                      "reminder_on, reminder_time, reminder_days) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                      [h.name, h.color, h.perWeek, created, rs.rows.item(0).p,
                       h.reminderOn ? 1 : 0, h.reminderTime, h.reminderDays])
    })
}

function updateHabit(id, h) {
    db().transaction(function (tx) {
        tx.executeSql("UPDATE habits SET name = ?, color = ?, per_week = ?, " +
                      "reminder_on = ?, reminder_time = ?, reminder_days = ? WHERE id = ?",
                      [h.name, h.color, h.perWeek, h.reminderOn ? 1 : 0,
                       h.reminderTime, h.reminderDays, id])
    })
}

function deleteHabit(id) {
    db().transaction(function (tx) {
        tx.executeSql("DELETE FROM checks WHERE habit_id = ?", [id])
        tx.executeSql("DELETE FROM habits WHERE id = ?", [id])
    })
}

// Växlar en dag. Om dagen ligger före skapandedatum flyttas det bakåt,
// så att man kan fylla i historik.
function toggle(habitId, day) {
    var now = false
    db().transaction(function (tx) {
        var rs = tx.executeSql("SELECT 1 FROM checks WHERE habit_id = ? AND day = ?",
                               [habitId, day])
        if (rs.rows.length > 0) {
            tx.executeSql("DELETE FROM checks WHERE habit_id = ? AND day = ?", [habitId, day])
        } else {
            tx.executeSql("INSERT INTO checks (habit_id, day) VALUES (?, ?)", [habitId, day])
            tx.executeSql("UPDATE habits SET created = ? WHERE id = ? AND created > ?",
                          [day, habitId, day])
            now = true
        }
    })
    return now
}
