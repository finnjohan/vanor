// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

// Liten ring som visar vanans poäng (0–1).
Item {
    id: ring
    property real value: 0
    property color ringColor: "#E95420"
    property real lineWidth: units.dp(4)
    property bool showText: false

    implicitWidth: units.gu(4)
    implicitHeight: units.gu(4)

    onValueChanged: canvas.requestPaint()
    onRingColorChanged: canvas.requestPaint()

    Canvas {
        id: canvas
        anchors.fill: parent
        onPaint: {
            var ctx = getContext("2d")
            ctx.reset()
            var r = Math.min(width, height) / 2 - ring.lineWidth / 2
            var cx = width / 2, cy = height / 2
            ctx.lineWidth = ring.lineWidth
            ctx.strokeStyle = Qt.rgba(ring.ringColor.r, ring.ringColor.g, ring.ringColor.b, 0.2)
            ctx.beginPath(); ctx.arc(cx, cy, r, 0, 2 * Math.PI); ctx.stroke()
            if (ring.value > 0.001) {
                ctx.strokeStyle = ring.ringColor
                ctx.lineCap = "round"
                ctx.beginPath()
                ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + 2 * Math.PI * Math.min(1, ring.value))
                ctx.stroke()
            }
        }
    }

    Label {
        anchors.centerIn: parent
        visible: ring.showText
        text: Math.round(ring.value * 100) + "%"
        textSize: Label.Large
        font.weight: Font.Light
    }
}
