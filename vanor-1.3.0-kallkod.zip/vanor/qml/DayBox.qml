// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

// En ruta som visar om en dag är avbockad. Tryck för att växla.
AbstractButton {
    id: box
    property bool checked: false
    property color habitColor: "#E95420"
    property real size: units.gu(3.4)

    width: units.gu(5)
    height: units.gu(6)

    Rectangle {
        anchors.centerIn: parent
        width: box.size
        height: box.size
        radius: width / 2
        color: box.checked ? box.habitColor : "transparent"
        border.width: box.checked ? 0 : units.dp(2)
        border.color: Qt.rgba(box.habitColor.r, box.habitColor.g, box.habitColor.b, 0.45)

        Label {
            anchors.centerIn: parent
            visible: box.checked
            text: "✓"
            color: "white"
            font.bold: true
            textSize: Label.Medium
        }
        Behavior on color { ColorAnimation { duration: 120 } }
    }
}
