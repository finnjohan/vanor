.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

// Enkel översättning. Källsträngarna är på engelska; här finns svenska.
// För att lägga till ett språk: lägg till ett nytt objekt och en rad i `languages`.

var languages = [
    { code: "en", name: "English" },
    { code: "sv", name: "Svenska" }
]

var sv = {
    "Habits": "Vanor",
    "New habit": "Ny vana",
    "Settings": "Inställningar",
    "Delete": "Ta bort",
    "Edit": "Redigera",
    "Streak: %1": "Streak: %1",
    "No habits yet": "Inga vanor än",
    "Add something you want to do regularly – exercise, read, take a walk – and check off the days.":
        "Lägg till något du vill göra regelbundet – träna, läsa, ta en promenad – och bocka av dagarna.",
    "Add habit": "Lägg till vana",
    "Delete habit?": "Ta bort vana?",
    "“%1” and all of its history will be deleted.": "”%1” och all dess historik tas bort.",
    "Cancel": "Avbryt",
    "Edit habit": "Redigera vana",
    "Save": "Spara",
    "Name": "Namn",
    "e.g. Exercise, Read 20 min, Meditate": "t.ex. Träna, Läsa 20 min, Meditera",
    "Goal": "Mål",
    "Color": "Färg",
    "Preview": "Förhandsvisning",
    "Reminder": "Påminnelse",
    "Remind me": "Påminn mig",
    "Time": "Tid",
    "Days": "Dagar",
    "The reminder rings like an alarm and is also listed in the Clock app.":
        "Påminnelsen ringer som ett larm och syns även i Klocka-appen.",
    "Score": "Poäng",
    "Since %1": "Sedan %1",
    "Current streak": "Nuvarande streak",
    "Best streak": "Bästa streak",
    "Total": "Totalt",
    "%1 times": "%1 ggr",
    "Score, last 90 days": "Poäng senaste 90 dagarna",
    "History": "Historik",
    "Tap a day to check it off or undo.": "Tryck på en dag för att bocka av eller ångra.",
    "Reminder at %1": "Påminnelse kl %1",
    "Appearance": "Utseende",
    "Theme": "Tema",
    "Automatic": "Automatiskt",
    "Light": "Ljust",
    "Dark": "Mörkt",
    "Language": "Språk",
    "Automatic (system language)": "Automatiskt (systemets språk)",
    "About": "Om",
    "A habit tracker inspired by Loop Habit Tracker. Your data is stored only on this device.":
        "En vanespårare inspirerad av Loop Habit Tracker. Dina data sparas bara på den här enheten.",
    "Version %1": "Version %1"
}

var tables = { sv: sv }

function systemLanguage(localeName) {
    var code = (localeName || "en").substring(0, 2)
    return tables[code] ? code : "en"
}

function tr(s, lang) {
    var t = tables[lang]
    return (t && t[s] !== undefined) ? t[s] : s
}
