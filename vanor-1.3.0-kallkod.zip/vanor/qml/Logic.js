.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

// Ren logik utan beroenden – lätt att testa.
// Datum representeras som strängar "YYYY-MM-DD" (lokal tid).

function pad(n) { return (n < 10 ? "0" : "") + n }

function dayKey(d) {
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate())
}

function parseKey(k) {
    var p = k.split("-")
    return new Date(parseInt(p[0], 10), parseInt(p[1], 10) - 1, parseInt(p[2], 10), 12)
}

function addDays(d, n) {
    var r = new Date(d.getFullYear(), d.getMonth(), d.getDate() + n, 12)
    return r
}

function today() {
    var n = new Date()
    return new Date(n.getFullYear(), n.getMonth(), n.getDate(), 12)
}

// Måndag = 0 ... söndag = 6 (svensk vecka)
function weekday(d) { return (d.getDay() + 6) % 7 }

function weekStart(d) { return addDays(d, -weekday(d)) }

var _dayNames = {
    sv: ["mån", "tis", "ons", "tor", "fre", "lör", "sön"],
    en: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
}
var _monthNames = {
    sv: ["jan", "feb", "mar", "apr", "maj", "jun", "jul", "aug", "sep", "okt", "nov", "dec"],
    en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
}

function dayName(i, lang) { return (_dayNames[lang] || _dayNames.en)[i] }
function monthName(i, lang) { return (_monthNames[lang] || _monthNames.en)[i] }

function formatDate(d, lang) {
    if (lang === "sv") return d.getDate() + " " + monthName(d.getMonth(), lang) + " " + d.getFullYear()
    return monthName(d.getMonth(), lang) + " " + d.getDate() + ", " + d.getFullYear()
}

// checks: objekt { "YYYY-MM-DD": true }
// Poäng 0–1: exponentiellt glidande medelvärde med halveringstid ~13 dagar.
// För vanor som inte är dagliga räknas en dag som "uppfylld" i den grad
// de senaste 7 dagarna når veckomålet.
function score(checks, createdKey, perWeek, todayDate) {
    var t = todayDate || today()
    var start = parseKey(createdKey)
    var m = Math.pow(0.5, 1 / 13)
    var s = 0
    var window = []   // senaste 7 dagarnas bockar (0/1)
    var inWindow = 0
    for (var d = start; d <= t; d = addDays(d, 1)) {
        var c = checks[dayKey(d)] ? 1 : 0
        window.push(c); inWindow += c
        if (window.length > 7) inWindow -= window.shift()
        var v
        if (perWeek >= 7) v = c
        else v = Math.min(1, inWindow / perWeek)
        s = s * m + v * (1 - m)
    }
    return s
}

// Serie av poäng per dag (för grafen), sista `days` dagarna.
function scoreSeries(checks, createdKey, perWeek, days, todayDate) {
    var t = todayDate || today()
    var out = []
    for (var i = days - 1; i >= 0; i--) {
        var d = addDays(t, -i)
        if (dayKey(d) < createdKey) out.push(0)
        else out.push(score(checks, createdKey, perWeek, d))
    }
    return out
}

function countInWeek(checks, ws) {
    var n = 0
    for (var i = 0; i < 7; i++) if (checks[dayKey(addDays(ws, i))]) n++
    return n
}

// Streak: dagar i rad för dagliga vanor, annars veckor i rad där målet nåtts.
// Pågående dag/vecka räknas bara om den redan är klar.
// Returnerar { current, best, unit: "dag"|"vecka" }
function streaks(checks, createdKey, perWeek, todayDate) {
    var t = todayDate || today()
    var start = parseKey(createdKey)
    var best = 0, run = 0, current = 0
    if (perWeek >= 7) {
        for (var d = start; d <= t; d = addDays(d, 1)) {
            if (checks[dayKey(d)]) { run++; if (run > best) best = run }
            else if (dayKey(d) !== dayKey(t)) run = 0
        }
        current = run
        return { current: current, best: best, unit: "dag" }
    }
    var ws = weekStart(start)
    var curWs = weekStart(t)
    for (var w = ws; w <= curWs; w = addDays(w, 7)) {
        var ok = countInWeek(checks, w) >= perWeek
        if (ok) { run++; if (run > best) best = run }
        else if (dayKey(w) !== dayKey(curWs)) run = 0
    }
    current = run
    return { current: current, best: best, unit: "vecka" }
}

function total(checks) {
    var n = 0
    for (var k in checks) if (checks[k]) n++
    return n
}

function unitText(n, unit, lang) {
    if (lang === "sv") {
        if (unit === "dag") return n + (n === 1 ? " dag" : " dagar")
        return n + (n === 1 ? " vecka" : " veckor")
    }
    if (unit === "dag") return n + (n === 1 ? " day" : " days")
    return n + (n === 1 ? " week" : " weeks")
}

function goalText(perWeek, lang) {
    if (lang === "sv") {
        if (perWeek >= 7) return "Varje dag"
        return perWeek + (perWeek === 1 ? " gång" : " gånger") + " i veckan"
    }
    if (perWeek >= 7) return "Every day"
    if (perWeek === 1) return "Once a week"
    return perWeek + " times a week"
}

// Påminnelsedagar som bitmask: bit 0 = måndag ... bit 6 = söndag
function daysText(mask, lang) {
    if (mask === 127) return lang === "sv" ? "alla dagar" : "every day"
    if (mask === 31) return lang === "sv" ? "mån–fre" : "Mon–Fri"
    if (mask === 96) return lang === "sv" ? "helger" : "weekends"
    var out = []
    for (var i = 0; i < 7; i++) if (mask & (1 << i)) out.push(dayName(i, lang))
    return out.join(", ")
}

// Nästa tillfälle (från `now`) då en påminnelse med tid "HH:MM" och dagmask ska gå.
function nextOccurrence(time, mask, now) {
    var p = time.split(":")
    var h = parseInt(p[0], 10), m = parseInt(p[1], 10)
    for (var i = 0; i < 8; i++) {
        var d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i, h, m, 0)
        if (d > now && (mask & (1 << weekday(d)))) return d
    }
    return null
}
