// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Logic.js" as Logic

Page {
    id: page
    property int habitId: -1
    property var habit: root.habitById(habitId)
    property date todayDate: Logic.today()

    readonly property color c: habit ? habit.color : "#E95420"
    readonly property var st: habit ? Logic.streaks(habit.checks, habit.created, habit.perWeek, todayDate)
                                    : { current: 0, best: 0, unit: "dag" }
    readonly property real sc: habit ? Logic.score(habit.checks, habit.created, habit.perWeek, todayDate) : 0

    Connections {
        target: root
        function onStorageUpdated() {
            page.habit = root.habitById(page.habitId)
            if (!page.habit) stack.pop()
        }
    }

    Connections {
        target: Qt.application
        function onStateChanged() {
            if (Qt.application.state === Qt.ApplicationActive) page.todayDate = Logic.today()
        }
    }

    header: PageHeader {
        id: header
        title: page.habit ? page.habit.name : ""
        trailingActionBar.actions: [
            Action {
                iconName: "edit"
                text: root.tr("Edit")
                onTriggered: stack.push(Qt.resolvedUrl("EditHabitPage.qml"), { habitId: page.habitId })
            }
        ]
    }

    Flickable {
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: content.height + units.gu(4)
        clip: true

        Column {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(2.5)

            // Översikt
            Row {
                width: parent.width
                spacing: units.gu(2)
                ScoreRing {
                    width: units.gu(11); height: width
                    lineWidth: units.dp(8)
                    value: page.sc
                    ringColor: page.c
                    showText: true
                }
                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: units.gu(0.5)
                    Label { text: root.tr("Score"); textSize: Label.Large; color: page.c }
                    Label {
                        text: page.habit ? Logic.goalText(page.habit.perWeek, root.lang) : ""
                        color: theme.palette.normal.backgroundSecondaryText
                    }
                    Label {
                        text: page.habit ? root.tr("Since %1").arg(Logic.formatDate(Logic.parseKey(page.habit.created), root.lang)) : ""
                        textSize: Label.Small
                        color: theme.palette.normal.backgroundSecondaryText
                    }
                    Label {
                        visible: root.remindersEnabled && (page.habit ? page.habit.reminderOn : false)
                        text: page.habit ? root.tr("Reminder at %1").arg(page.habit.reminderTime)
                                           + " · " + Logic.daysText(page.habit.reminderDays, root.lang) : ""
                        textSize: Label.Small
                        color: theme.palette.normal.backgroundSecondaryText
                    }
                }
            }

            // Statistik
            Row {
                width: parent.width
                Repeater {
                    model: [
                        { label: root.tr("Current streak"), value: Logic.unitText(page.st.current, page.st.unit, root.lang) },
                        { label: root.tr("Best streak"), value: Logic.unitText(page.st.best, page.st.unit, root.lang) },
                        { label: root.tr("Total"), value: page.habit ? root.tr("%1 times").arg(Logic.total(page.habit.checks)) : "" }
                    ]
                    Column {
                        width: parent.width / 3
                        spacing: units.gu(0.3)
                        Label {
                            width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            text: modelData.value
                            textSize: Label.Large
                            color: page.c
                        }
                        Label {
                            width: parent.width
                            horizontalAlignment: Text.AlignHCenter
                            text: modelData.label
                            textSize: Label.XSmall
                            color: theme.palette.normal.backgroundSecondaryText
                        }
                    }
                }
            }

            // Poänggraf
            Column {
                width: parent.width
                spacing: units.gu(1)
                Label { text: root.tr("Score, last 90 days"); font.weight: Font.Medium }
                Canvas {
                    id: chart
                    width: parent.width
                    height: units.gu(14)
                    property var series: page.habit ? Logic.scoreSeries(page.habit.checks, page.habit.created,
                                                                        page.habit.perWeek, 90, page.todayDate) : []
                    onSeriesChanged: requestPaint()
                    onWidthChanged: requestPaint()
                    onPaint: {
                        var ctx = getContext("2d")
                        ctx.reset()
                        var w = width, h = height, n = series.length
                        ctx.strokeStyle = Qt.rgba(0.5, 0.5, 0.5, 0.25)
                        ctx.lineWidth = 1
                        for (var g = 0; g <= 4; g++) {
                            var y = Math.round(h - g * h / 4) + 0.5
                            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke()
                        }
                        if (n < 2) return
                        ctx.beginPath()
                        for (var i = 0; i < n; i++) {
                            var x = i * w / (n - 1), yy = h - series[i] * (h - 2) - 1
                            if (i === 0) ctx.moveTo(x, yy); else ctx.lineTo(x, yy)
                        }
                        ctx.lineTo(w, h); ctx.lineTo(0, h); ctx.closePath()
                        ctx.fillStyle = Qt.rgba(page.c.r, page.c.g, page.c.b, 0.15)
                        ctx.fill()
                        ctx.beginPath()
                        for (var j = 0; j < n; j++) {
                            var x2 = j * w / (n - 1), y2 = h - series[j] * (h - 2) - 1
                            if (j === 0) ctx.moveTo(x2, y2); else ctx.lineTo(x2, y2)
                        }
                        ctx.strokeStyle = page.c
                        ctx.lineWidth = units.dp(2)
                        ctx.stroke()
                    }
                }
            }

            // Historik – rutnät med veckor som kolumner, tryck för att ändra
            Column {
                id: history
                width: parent.width
                spacing: units.gu(1)
                readonly property real cell: units.gu(2.6)
                readonly property int weeks: Math.max(4, Math.floor((width - units.gu(4)) / cell))
                readonly property date firstWeek: Logic.addDays(Logic.weekStart(page.todayDate), -7 * (weeks - 1))

                Label { text: root.tr("History"); font.weight: Font.Medium }
                Label {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    text: root.tr("Tap a day to check it off or undo.")
                    textSize: Label.Small
                    color: theme.palette.normal.backgroundSecondaryText
                }

                Row {
                    // Veckodagsetiketter
                    Column {
                        width: units.gu(4)
                        Item { width: 1; height: history.cell }
                        Repeater {
                            model: 7
                            Item {
                                width: units.gu(4); height: history.cell
                                Label {
                                    anchors.verticalCenter: parent.verticalCenter
                                    visible: index % 2 === 0
                                    text: Logic.dayName(index, root.lang)
                                    textSize: Label.XSmall
                                    color: theme.palette.normal.backgroundSecondaryText
                                }
                            }
                        }
                    }
                    Repeater {
                        model: history.weeks
                        Column {
                            property date ws: Logic.addDays(history.firstWeek, 7 * index)
                            // Månadsetikett när en ny månad börjar
                            Item {
                                width: history.cell; height: history.cell
                                Label {
                                    anchors.bottom: parent.bottom
                                    visible: index === 0 || ws.getMonth() !== Logic.addDays(ws, -7).getMonth()
                                    text: Logic.monthName(ws.getMonth(), root.lang)
                                    textSize: Label.XSmall
                                    color: theme.palette.normal.backgroundSecondaryText
                                }
                            }
                            Repeater {
                                model: 7
                                AbstractButton {
                                    id: cellBtn
                                    width: history.cell; height: history.cell
                                    property date d: Logic.addDays(ws, index)
                                    property string key: Logic.dayKey(d)
                                    property bool future: d > page.todayDate
                                    property bool done: page.habit ? page.habit.checks[key] === true : false
                                    enabled: !future
                                    onClicked: root.toggleDay(page.habitId, key)
                                    Rectangle {
                                        anchors.fill: parent
                                        anchors.margins: units.dp(2)
                                        radius: units.dp(3)
                                        color: cellBtn.done ? page.c
                                             : cellBtn.future ? "transparent"
                                             : Qt.rgba(0.5, 0.5, 0.5, 0.15)
                                        border.width: cellBtn.key === Logic.dayKey(page.todayDate) ? units.dp(2) : 0
                                        border.color: theme.palette.normal.baseText
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
