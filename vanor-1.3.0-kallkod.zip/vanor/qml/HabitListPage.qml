// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import Lomiri.Components.Popups 1.3
import "Logic.js" as Logic

Page {
    id: page

    header: PageHeader {
        id: header
        title: root.tr("Habits")
        trailingActionBar.actions: [
            Action {
                iconName: "settings"
                text: root.tr("Settings")
                onTriggered: stack.push(Qt.resolvedUrl("SettingsPage.qml"))
            },
            Action {
                iconName: "add"
                text: root.tr("New habit")
                onTriggered: stack.push(Qt.resolvedUrl("EditHabitPage.qml"), { habitId: -1 })
            }
        ]
    }

    // Hur många dagar som får plats i listan (3–7)
    readonly property int dayCount: Math.max(3, Math.min(7,
                                    Math.floor((width - units.gu(24)) / units.gu(5))))
    property date todayDate: Logic.today()

    // Uppdatera "idag" när appen kommer tillbaka efter midnatt
    Connections {
        target: Qt.application
        function onStateChanged() {
            if (Qt.application.state === Qt.ApplicationActive) page.todayDate = Logic.today()
        }
    }

    // Rubrikrad med veckodagar
    Item {
        id: dayHeader
        anchors { top: header.bottom; left: parent.left; right: parent.right }
        height: units.gu(4)
        visible: root.habits.count > 0

        Row {
            anchors { right: parent.right; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
            Repeater {
                model: page.dayCount
                Column {
                    width: units.gu(5)
                    property date d: Logic.addDays(page.todayDate, -(page.dayCount - 1 - index))
                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: Logic.dayName(Logic.weekday(d), root.lang)
                        textSize: Label.XSmall
                        color: theme.palette.normal.backgroundSecondaryText
                    }
                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: d.getDate()
                        textSize: Label.Small
                        font.bold: index === page.dayCount - 1
                    }
                }
            }
        }
    }

    ListView {
        id: list
        anchors { top: dayHeader.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        clip: true
        model: root.habits

        delegate: ListItem {
            id: item
            height: units.gu(8)
            divider.visible: true

            property var checks: JSON.parse(model.checksJson)
            property var st: Logic.streaks(checks, model.created, model.perWeek, page.todayDate)
            property real sc: Logic.score(checks, model.created, model.perWeek, page.todayDate)

            // Exponera värden till inre Repeater (som har ett eget "model")
            property int habitIdValue: model.habitId
            property color parentColor: model.habitColor

            onClicked: stack.push(Qt.resolvedUrl("HabitDetailPage.qml"), { habitId: model.habitId })

            leadingActions: ListItemActions {
                actions: [
                    Action {
                        iconName: "delete"
                        text: root.tr("Delete")
                        onTriggered: PopupUtils.open(deleteDialog, page,
                                                     { habitId: model.habitId, habitName: model.name })
                    }
                ]
            }
            trailingActions: ListItemActions {
                actions: [
                    Action {
                        iconName: "edit"
                        text: root.tr("Edit")
                        onTriggered: stack.push(Qt.resolvedUrl("EditHabitPage.qml"), { habitId: model.habitId })
                    }
                ]
            }

            ScoreRing {
                id: ring
                anchors { left: parent.left; leftMargin: units.gu(2); verticalCenter: parent.verticalCenter }
                width: units.gu(3.5); height: width
                value: item.sc
                ringColor: model.habitColor
            }

            Column {
                anchors {
                    left: ring.right; leftMargin: units.gu(1.5)
                    right: days.left; rightMargin: units.gu(1)
                    verticalCenter: parent.verticalCenter
                }
                spacing: units.gu(0.3)
                Label {
                    width: parent.width
                    text: model.name
                    elide: Text.ElideRight
                    color: model.habitColor
                    font.weight: Font.Medium
                }
                Row {
                    width: parent.width
                    spacing: (model.reminderOn && root.remindersEnabled) ? units.gu(0.5) : 0
                    Icon {
                        name: "alarm-clock"
                        visible: model.reminderOn && root.remindersEnabled
                        width: units.gu(1.6); height: width
                        anchors.verticalCenter: parent.verticalCenter
                        color: theme.palette.normal.backgroundSecondaryText
                    }
                    Label {
                        width: parent.width - ((model.reminderOn && root.remindersEnabled) ? units.gu(2.1) : 0)
                        elide: Text.ElideRight
                        textSize: Label.Small
                        color: theme.palette.normal.backgroundSecondaryText
                        text: item.st.current > 0
                              ? root.tr("Streak: %1").arg(Logic.unitText(item.st.current, item.st.unit, root.lang))
                              : Logic.goalText(model.perWeek, root.lang)
                    }
                }
            }

            Row {
                id: days
                anchors { right: parent.right; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                Repeater {
                    model: page.dayCount
                    DayBox {
                        property string key: Logic.dayKey(Logic.addDays(page.todayDate, -(page.dayCount - 1 - index)))
                        checked: item.checks[key] === true
                        habitColor: item.parentColor
                        onClicked: root.toggleDay(item.habitIdValue, key)
                    }
                }
            }
        }
    }

    // Tomt läge
    Column {
        anchors.centerIn: parent
        width: parent.width - units.gu(8)
        spacing: units.gu(2)
        visible: root.habits.count === 0
        Label {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            text: root.tr("No habits yet")
            textSize: Label.Large
        }
        Label {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            color: theme.palette.normal.backgroundSecondaryText
            text: root.tr("Add something you want to do regularly – exercise, read, take a walk – and check off the days.")
        }
        Button {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.tr("Add habit")
            color: theme.palette.normal.positive
            onClicked: stack.push(Qt.resolvedUrl("EditHabitPage.qml"), { habitId: -1 })
        }
    }

    Component {
        id: deleteDialog
        Dialog {
            id: dlg
            property int habitId: -1
            property string habitName: ""
            title: root.tr("Delete habit?")
            text: root.tr("“%1” and all of its history will be deleted.").arg(habitName)
            Button {
                text: root.tr("Delete")
                color: theme.palette.normal.negative
                onClicked: {
                    root.deleteHabit(dlg.habitId)
                    PopupUtils.close(dlg)
                }
            }
            Button {
                text: root.tr("Cancel")
                onClicked: PopupUtils.close(dlg)
            }
        }
    }
}
