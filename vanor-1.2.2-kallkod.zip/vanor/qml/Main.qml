// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Storage.js" as Storage
import "Logic.js" as Logic
import "I18n.js" as I18n

MainView {
    id: root
    objectName: "mainView"
    applicationName: "vanor"
    automaticOrientation: true

    width: units.gu(45)
    height: units.gu(75)

    readonly property string version: "1.2.2"

    // Påminnelser använder systemlarm och kräver AppArmor-gruppen "calendar",
    // som granskas manuellt i OpenStore. Sätt till true och lägg till "calendar"
    // i vanor.apparmor för att slå på dem igen.
    readonly property bool remindersEnabled: false

    // Gemensamma färger för vanor
    readonly property var habitColors: ["#E95420", "#3EB34F", "#19B6EE", "#A35AE8",
                                        "#F99B0F", "#ED3146", "#2C8FAF", "#8E8E8E"]

    // ---- Inställningar --------------------------------------------------
    property string themeSetting: Storage.setting("theme", "auto")      // auto | light | dark
    property string langSetting: Storage.setting("language", "auto")    // auto | sv | en
    readonly property string lang: langSetting === "auto" ? I18n.systemLanguage(Qt.locale().name)
                                                          : langSetting

    // Översätt en sträng. Bindningar som anropar tr() uppdateras när språket byts.
    function tr(s) { return I18n.tr(s, lang) }

    function setTheme(value) {
        themeSetting = value
        Storage.setSetting("theme", value)
        applyTheme()
    }

    function setLanguage(value) {
        langSetting = value
        Storage.setSetting("language", value)
    }

    function applyTheme() {
        if (themeSetting === "dark") theme.name = "Lomiri.Components.Themes.SuruDark"
        else if (themeSetting === "light") theme.name = "Lomiri.Components.Themes.Ambiance"
        else theme.name = ""   // följ systemet
    }

    // ---- Data -----------------------------------------------------------

    // Skickas när data har ändrats så att öppna sidor kan läsa om
    signal storageUpdated()

    ListModel { id: habitModel }
    property alias habits: habitModel

    function reload() {
        habitModel.clear()
        var list = Storage.habits()
        for (var i = 0; i < list.length; i++) {
            var h = list[i]
            habitModel.append({ habitId: h.id, name: h.name, habitColor: h.color,
                                perWeek: h.perWeek, created: h.created,
                                reminderOn: h.reminderOn, reminderTime: h.reminderTime,
                                reminderDays: h.reminderDays,
                                checksJson: JSON.stringify(Storage.checks(h.id)) })
        }
        storageUpdated()
    }

    function refreshHabit(id) {
        var list = Storage.habits()
        for (var i = 0; i < habitModel.count; i++) {
            if (habitModel.get(i).habitId === id) {
                for (var j = 0; j < list.length; j++) {
                    if (list[j].id === id) {
                        habitModel.setProperty(i, "created", list[j].created)
                        break
                    }
                }
                habitModel.setProperty(i, "checksJson", JSON.stringify(Storage.checks(id)))
                break
            }
        }
        storageUpdated()
    }

    // h: { name, color, perWeek, reminderOn, reminderTime, reminderDays }
    function saveHabit(id, h) {
        var old = id >= 0 ? habitById(id) : null
        if (id < 0) Storage.addHabit(h, Logic.dayKey(Logic.today()))
        else Storage.updateHabit(id, h)
        syncReminder(old ? old.name : h.name, h)
        reload()
    }

    function deleteHabit(id) {
        var old = habitById(id)
        if (old) cancelReminders(old.name)
        Storage.deleteHabit(id)
        reload()
    }

    function habitById(id) {
        for (var i = 0; i < habitModel.count; i++) {
            var h = habitModel.get(i)
            if (h.habitId === id)
                return { id: h.habitId, name: h.name, color: h.habitColor,
                         perWeek: h.perWeek, created: h.created,
                         reminderOn: h.reminderOn, reminderTime: h.reminderTime,
                         reminderDays: h.reminderDays,
                         checks: JSON.parse(h.checksJson) }
        }
        return null
    }

    function toggleDay(id, day) {
        Storage.toggle(id, day)
        refreshHabit(id)
    }

    // ---- Påminnelser ----------------------------------------------------
    // Påminnelser är systemlarm (samma som Klocka-appen). Varje vana har
    // ett återkommande larm med meddelandet "Vanor: <namn>".

    readonly property string alarmPrefix: "Vanor: "

    Loader {
        id: alarmLoader
        active: root.remindersEnabled
        sourceComponent: AlarmModel {}
    }
    Component { id: alarmComponent; Alarm {} }
    property var pendingAlarms: []

    function cancelReminders(name) {
        var alarmModel = alarmLoader.item
        if (!alarmModel) return
        var doomed = []
        for (var i = 0; i < alarmModel.count; i++) {
            var a = alarmModel.get(i)
            if (a && a.message === alarmPrefix + name) doomed.push(a)
        }
        for (var j = 0; j < doomed.length; j++) doomed[j].cancel()
    }

    function syncReminder(oldName, h) {
        cancelReminders(oldName)
        if (oldName !== h.name) cancelReminders(h.name)
        if (!remindersEnabled || !h.reminderOn || h.reminderDays === 0) return
        var when = Logic.nextOccurrence(h.reminderTime, h.reminderDays, new Date())
        if (!when) return
        var a = alarmComponent.createObject(root)
        a.message = alarmPrefix + h.name
        a.type = Alarm.Repeating
        a.daysOfWeek = h.reminderDays   // samma bitordning: måndag = 1 ... söndag = 64
        a.date = when
        a.enabled = true
        a.save()
        pendingAlarms.push(a)           // behåll referensen tills sparningen är klar
    }

    PageStack {
        id: stack
        Component.onCompleted: {
            root.applyTheme()
            root.reload()
            push(Qt.resolvedUrl("HabitListPage.qml"))
        }
    }
}
