# Vanor – vanespårning för Ubuntu Touch

En enkel app för att följa vanor, inspirerad av Android-appen
[Loop Habit Tracker](https://github.com/iSoron/uhabits) (GPLv3). Koden här är
nyskriven i QML och innehåller ingen kod från Loop.

## Funktioner
- Lista med vanor. Bocka av de senaste dagarna direkt i listan.
- Mål: varje dag eller 1–6 gånger i veckan.
- Poäng (0–100 %) som belönar regelbundenhet. Den beräknas som ett glidande medelvärde med en halveringstid på cirka 13 dagar.
- Streak räknas i dagar för dagliga vanor och i veckor för veckomål.
- Detaljsida med poänggraf för de senaste 90 dagarna och ett historikrutnät där du kan trycka för att ändra.
- All data sparas lokalt i SQLite.
- Svenska och engelska. Appen följer systemspråket som standard och kan ändras under Inställningar.
- Mörkt, ljust eller automatiskt tema.
- Påminnelser per vana med tid och veckodagar. De är avstängda i OpenStore-versionen, se nedan.

## Bygga och installera
Med [clickable](https://clickable-ut.dev):

```bash
clickable build            # bygger .click
clickable install          # installerar på ansluten telefon (via adb/ssh)
clickable desktop          # testkör på datorn
```

Utan clickable, med telefonen i utvecklarläge och ansluten med USB:

```bash
adb push vanor_1.2.2_all.click /home/phablet/Downloads/
adb shell gdbus call --system --dest com.lomiri.click --object-path /com/lomiri/click \
    --method com.lomiri.click.Install /home/phablet/Downloads/vanor_1.2.2_all.click
```

## Struktur
| Fil | Innehåll |
|---|---|
| `qml/Main.qml` | MainView, datamodell, navigering |
| `qml/HabitListPage.qml` | Startsidan med vanor och dagsrutor |
| `qml/HabitDetailPage.qml` | Statistik, graf och historik |
| `qml/EditHabitPage.qml` | Skapa och redigera vana |
| `qml/SettingsPage.qml` | Tema, språk, om |
| `qml/Logic.js` | Poäng, streaks, datum och påminnelsetider (ren JS) |
| `qml/I18n.js` | Översättningar (lägg till fler språk här) |
| `qml/Storage.js` | SQLite via QtQuick.LocalStorage |

### Målplattform
Version 1.2 är byggd för **Ubuntu Touch 24.04-1.x** (Qt 5.15), med ramverket
`ubuntu-touch-24.04-1.x` och AppArmor-policyn `2404.1`. Kräver clickable 8.4.0 eller senare.
Paketet installeras inte på 20.04. Använd version 1.1 för telefoner som fortfarande kör 20.04.

Ändringar mot 1.1:
- Ramverk, AppArmor-policy och `clickable.yaml` är satta för 24.04-1.x.
- `Connections` använder den nya syntaxen `function onFoo() { }` (Qt 5.15).
  Den fungerar inte på 20.04 (Qt 5.12), och därför har 20.04 en egen version.
- Detaljsidan uppdaterar "idag" när appen öppnas igen efter midnatt.

## Behörigheter och påminnelser
Version 1.2.2 i OpenStore har **påminnelserna avstängda** och behöver inga extra behörigheter,
så den går igenom OpenStores automatiska granskning.

Påminnelserna finns kvar i koden. Så här slår du på dem igen:
1. Sätt `remindersEnabled: true` i `qml/Main.qml`.
2. Lägg till `"calendar"` under `policy_groups` i `vanor.apparmor`.

Behörigheten `calendar` är *reserved* och kräver manuell granskning i OpenStore. Kontakta en admin
i OpenStores Telegram-grupp med en länk till koden.

## Idéer för nästa version
Export/import (CSV), hemskärmsikon per vana och omsortering med dra-och-släpp.

## Licens
Copyright © 2026 Johan Finn

Vanor är fri programvara och licensieras under **GNU General Public License v3.0 eller senare**
(GPL-3.0-or-later). Se [LICENSE](LICENSE). Du får använda, ändra och sprida appen, men
ändrade versioner som sprids måste också vara öppna under samma licens.
